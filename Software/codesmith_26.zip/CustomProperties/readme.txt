This project contains custom property types that can be used on your templates.
