Module EntryPoint
    Sub Main()
        Dim stringhashtable As VBCodeGeneratorSample.StringHashtable = New VBCodeGeneratorSample.StringHashtable
        Dim stringinthashtable As VBCodeGeneratorSample.StringIntHashtable = New VBCodeGeneratorSample.StringIntHashtable
        Dim inthashtable As VBCodeGeneratorSample.IntHashtable = New VBCodeGeneratorSample.IntHashtable
    End Sub
End Module
