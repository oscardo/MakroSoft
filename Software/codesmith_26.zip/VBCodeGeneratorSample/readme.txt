This project contains a sample of using the VS.NET custom tool to simulate generics.

You can also use GenerateCode.bat from the command line to generate the code.