Public Class MergeSample
    Public Sub SomeCustomMethod()
        ' This is my custom code that I don't want over-ridden.
    End Sub

#Region "Sample Generated Region"
    'This comment will be over-ridden with the output of the template.
#End Region
End Class
