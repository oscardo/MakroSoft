This project contains a sample of using the VS.NET custom tool to simulate generics.

You can also use GenerateCode.bat from the command line to generate the code.

** NOTE: In order for the businessobject.xml file to generate correctly you will need to have the .NET SDK samples installed.