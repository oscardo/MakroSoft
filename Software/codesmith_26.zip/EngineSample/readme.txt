This project contains a sample of using the CodeSmith.Engine.dll programatically.
