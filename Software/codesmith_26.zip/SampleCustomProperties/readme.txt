This project contains a sample of creating custom types and type editors for use as CodeSmith properties.

The PurchaseOrderXml.cst contains an example of using the XML support in CodeSmith.

Try double-clicking on the SampleCustomProperties.cst template in windows explorer to see these custom types in use.

** NOTE: I know that I need to include some comments in this code, but I just wanted to go ahead and get it out there for now.